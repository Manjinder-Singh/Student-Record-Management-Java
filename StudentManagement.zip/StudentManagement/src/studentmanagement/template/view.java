/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rascal.template;

/**
 *
 * @author PARVINDER
 */
public class view {
    int studentid;

    public int getStudentid() {
        return studentid;
    }

    public void setStudentid(int studentid) {
        this.studentid = studentid;
    }
    
}
