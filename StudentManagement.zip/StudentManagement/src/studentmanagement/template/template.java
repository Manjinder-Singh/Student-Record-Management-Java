/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package template;

/**
 *
 * @author HarshDeep Singh
 */
public class template {
    
    String subject,sub_code,sem,branch,id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    Double quiz1,mst,quiz2,est,total,lab;


   
    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public Double getEst() {
        return est;
    }

    public void setEst(Double est) {
        this.est = est;
    }

    
    public Double getLab() {
        return lab;
    }

    public void setLab(Double lab) {
        this.lab = lab;
    }

    public Double getMst() {
        return mst;
    }

    public void setMst(Double mst) {
        this.mst = mst;
    }

    public Double getQuiz1() {
        return quiz1;
    }

    public void setQuiz1(Double quiz1) {
        this.quiz1 = quiz1;
    }

    public Double getQuiz2() {
        return quiz2;
    }

    public void setQuiz2(Double quiz2) {
        this.quiz2 = quiz2;
    }

    public String getSem() {
        return sem;
    }

    public void setSem(String sem) {
        this.sem = sem;
    }

    public String getSub_code() {
        return sub_code;
    }

    public void setSub_code(String sub_code) {
        this.sub_code = sub_code;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    
}
