/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentManagement.template;

/**
 *
 * @author PARVINDER
 */
public class personalinfotemplate {
    String name,addr,fname,mname,gender,month,course,branch,feecategory,femail,feecategory1,feecategory2;
      String   Studentcontactno,smail, mothercont,fathercont,  memail,feewaiver,feestatus,day,category,blood,section,advisor,city,state ,country;

    public String getStudentcontactno() {
        return Studentcontactno;
    }

    public void setStudentcontactno(String Studentcontactno) {
        this.Studentcontactno = Studentcontactno;
    }

    public String getSmail() {
        return smail;
    }

    public void setSmail(String smail) {
        this.smail = smail;
    }

    public String getFathercont() {
        return fathercont;
    }

    public void setFathercont(String fathercont) {
        this.fathercont = fathercont;
    }

    public String getMothercont() {
        return mothercont;
    }

    public void setMothercont(String mothercont) {
        this.mothercont = mothercont;
    }
            int collegerollno,id,unirollno,dd,year,dateofbirth,semester;

    public int getCollegerollno() {
        return collegerollno;
    }

    public void setCollegerollno(int collegerollno) {
        this.collegerollno = collegerollno;
    }

    public int getDd() {
        return dd;
    }

    public void setDd(int dd) {
        this.dd = dd;
    }

    public String getFeecategory1() {
        return feecategory1;
    }

    public void setFeecategory1(String feecategory1) {
        this.feecategory1 = feecategory1;
    }

    public String getFeecategory2() {
        return feecategory2;
    }

    public void setFeecategory2(String feecategory2) {
        this.feecategory2 = feecategory2;
    }

            
    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(int dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

   

    public String getAdvisor() {
        return advisor;
    }

    public void setAdvisor(String advisor) {
        this.advisor = advisor;
    }

    public String getBlood() {
        return blood;
    }

    public void setBlood(String blood) {
        this.blood = blood;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getcollegerollno() {
        return collegerollno;
    }

    public void setcollegerollno(int collegerollno) {
        this.collegerollno = collegerollno;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

   

    
    public String getFeecategory() {
        return feecategory;
    }

    public void setFeecategory(String feecategory) {
        this.feecategory = feecategory;
    }

    public String getFeestatus() {
        return feestatus;
    }

    public void setFeestatus(String feestatus) {
        this.feestatus = feestatus;
    }

    public String getFeewaiver() {
        return feewaiver;
    }

    public void setFeewaiver(String feewaiver) {
        this.feewaiver = feewaiver;
    }

    public String getFemail() {
        return femail;
    }

    public void setFemail(String femail) {
        this.femail = femail;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMemail() {
        return memail;
    }

    public void setMemail(String memail) {
        this.memail = memail;
    }


    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

   
    public int getUnirollno() {
        return unirollno;
    }

    public void setUnirollno(int unirollno) {
        this.unirollno = unirollno;
    }


}